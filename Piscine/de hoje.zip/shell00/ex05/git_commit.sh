git log --format="%H" -5
