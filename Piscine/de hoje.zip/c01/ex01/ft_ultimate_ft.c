/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_ft.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: edesanta <edesanta@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/27 23:50:26 by edesanta          #+#    #+#             */
/*   Updated: 2023/06/28 12:41:30 by edesanta         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// Create a function that takes a pointer to pointer to pointer to
//  pointer to pointer
// to pointer to pointer to pointer to pointer to int as
// a parameter and sets the value
// "42" to that int.

void	ft_ultimate_ft(int *********nbr)
{
	*********nbr = 42;
}
