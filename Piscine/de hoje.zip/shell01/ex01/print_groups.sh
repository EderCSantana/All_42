id -ng $FT_USER | tr '' ',' | tr -d '\n'

